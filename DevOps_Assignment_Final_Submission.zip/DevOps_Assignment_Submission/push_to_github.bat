@echo off
echo =======================================================
echo   DevOps Assignment Submission - GitHub Push Helper
echo   Author Email: saifulmunna668@gmail.com
echo =======================================================
echo.
set /p REPO_URL="Enter your GitHub Repository URL (e.g., https://github.com/USERNAME/REPO_NAME.git): "

if "%REPO_URL%"=="" (
    echo Error: No repository URL entered.
    pause
    exit /b 1
)

echo.
echo Configuring remote origin to %REPO_URL%...
git remote remove origin 2>nul
git remote add origin %REPO_URL%

echo.
echo Renaming branch to main...
git branch -M main

echo.
echo Pushing assignment files, PDF, DOCX, ZIP, and artefacts to GitHub...
git push -u origin main

echo.
if %ERRORLEVEL% equ 0 (
    echo =======================================================
    echo   SUCCESS! Assignment pushed to GitHub successfully.
    echo =======================================================
) else (
    echo =======================================================
    echo   Push encountered an error. Please verify your GitHub 
    echo   permissions or Personal Access Token (PAT).
    echo =======================================================
)
pause
