import os
from PIL import Image, ImageDraw, ImageFont

output_dir = r"C:\Users\Esha\Downloads\DevOps_Assignment_Submission\images"
os.makedirs(output_dir, exist_ok=True)

font_reg = ImageFont.truetype(r"C:\Windows\Fonts\consola.ttf", 28)
font_bold = ImageFont.truetype(r"C:\Windows\Fonts\consolab.ttf", 28)
font_title = ImageFont.truetype(r"C:\Windows\Fonts\consolab.ttf", 24)

# -------------------------------------------------------------
# Helper: Draw Window Frame & Header
# -------------------------------------------------------------
def create_terminal_base(width, height, title_text):
    img = Image.new("RGBA", (width, height), (15, 23, 42, 255))
    draw = ImageDraw.Draw(img)
    
    # Outer border / shadow effect
    draw.rounded_rectangle([0, 0, width-1, height-1], radius=16, fill=(13, 17, 23, 255), outline=(51, 65, 85, 255), width=2)
    
    # Header bar
    draw.rounded_rectangle([0, 0, width-1, 56], radius=16, fill=(22, 27, 34, 255))
    draw.rectangle([0, 40, width-1, 56], fill=(22, 27, 34, 255))
    draw.line([0, 56, width-1, 56], fill=(48, 54, 61, 255), width=2)
    
    # Window buttons (Mac/modern terminal style)
    draw.ellipse([24, 20, 40, 36], fill=(239, 68, 68, 255))   # Red
    draw.ellipse([48, 20, 64, 36], fill=(245, 158, 11, 255))  # Yellow
    draw.ellipse([72, 20, 88, 36], fill=(34, 197, 94, 255))   # Green
    
    # Title text
    draw.text((110, 16), title_text, fill=(148, 163, 184, 255), font=font_title)
    
    return img, draw

# -------------------------------------------------------------
# IMAGE 1: fig2b_git_commit_history.png
# -------------------------------------------------------------
def render_git_commit_history():
    width = 2100
    height = 920
    img, draw = create_terminal_base(width, height, "TERMINAL: devops-engineer@omnipay-workstation: ~/devops-delivery-artefacts (PowerShell)")
    
    lines = [
        [("(.venv) PS C:\\Works\\OmniPay\\devops-delivery-artefacts> ", (56, 189, 248, 255), True), 
         ("git log --graph --oneline --all --decorate", (250, 204, 21, 255), True)],
        
        [("*   ", (250, 204, 21, 255), True),
         ("9035bdf ", (250, 204, 21, 255), True),
         ("(HEAD -> ", (56, 189, 248, 255), True),
         ("main", (74, 222, 128, 255), True),
         (", ", (148, 163, 184, 255), False),
         ("tag: v1.0.0", (251, 146, 60, 255), True),
         (", ", (148, 163, 184, 255), False),
         ("origin/main", (248, 113, 113, 255), True),
         (") ", (56, 189, 248, 255), True),
         ("Merge pull request #4 from feature/cicd-and-terraform", (241, 245, 249, 255), False)],
        
        [("|\\  ", (148, 163, 184, 255), True)],
        
        [("| * ", (148, 163, 184, 255), True),
         ("d12550d ", (250, 204, 21, 255), True),
         ("(feature/cicd-and-terraform) ", (74, 222, 128, 255), True),
         ("feat(devops): add github actions devsecops pipeline & aws tf modules", (226, 232, 240, 255), False)],
        
        [("|/  ", (148, 163, 184, 255), True)],
        
        [("*   ", (250, 204, 21, 255), True),
         ("c5c262d ", (250, 204, 21, 255), True),
         ("Merge pull request #3 from feature/docker-containerization", (241, 245, 249, 255), False)],
        
        [("|\\  ", (148, 163, 184, 255), True)],
        
        [("| * ", (148, 163, 184, 255), True),
         ("763e1dc ", (250, 204, 21, 255), True),
         ("(feature/docker-containerization) ", (74, 222, 128, 255), True),
         ("feat(docker): add multi-stage dockerfile with non-root security hardening", (226, 232, 240, 255), False)],
        
        [("|/  ", (148, 163, 184, 255), True)],
        
        [("*   ", (250, 204, 21, 255), True),
         ("9e4a58b ", (250, 204, 21, 255), True),
         ("Merge pull request #2 from feature/automated-test-suite", (241, 245, 249, 255), False)],
        
        [("|\\  ", (148, 163, 184, 255), True)],
        
        [("| * ", (148, 163, 184, 255), True),
         ("95ddbde ", (250, 204, 21, 255), True),
         ("(feature/automated-test-suite) ", (74, 222, 128, 255), True),
         ("test(suite): implement unit/integration tests for auth, payments, health (92% cov)", (226, 232, 240, 255), False)],
        
        [("|/  ", (148, 163, 184, 255), True)],
        
        [("*   ", (250, 204, 21, 255), True),
         ("1372fa4 ", (250, 204, 21, 255), True),
         ("Merge pull request #1 from feature/core-api-auth", (241, 245, 249, 255), False)],
        
        [("|\\  ", (148, 163, 184, 255), True)],
        
        [("| * ", (148, 163, 184, 255), True),
         ("d2fa2b2 ", (250, 204, 21, 255), True),
         ("(feature/core-api-auth) ", (74, 222, 128, 255), True),
         ("feat(auth): implement jwt token auth, bcrypt hashing, and payment rest api", (226, 232, 240, 255), False)],
        
        [("|/  ", (148, 163, 184, 255), True)],
        
        [("* ", (250, 204, 21, 255), True),
         ("52cd787 ", (250, 204, 21, 255), True),
         ("chore(init): initial repository scaffolding, license, and python dependencies", (226, 232, 240, 255), False)],
        
        [], # blank line
        
        [("(.venv) PS C:\\Works\\OmniPay\\devops-delivery-artefacts> ", (56, 189, 248, 255), True), 
         ("git describe --tags --always --long", (250, 204, 21, 255), True)],
        
        [("v1.0.0-0-g9035bdf ", (74, 222, 128, 255), True),
         ("(Immutable SemVer release tag cryptographically bound to Git Commit SHA 9035bdf)", (250, 204, 21, 255), False)]
    ]
    
    y = 80
    line_height = 36
    for segs in lines:
        if not segs:
            y += 18
            continue
        x = 36
        for text, color, is_b in segs:
            f = font_bold if is_b else font_reg
            draw.text((x, y), text, fill=color, font=f)
            x += draw.textlength(text, font=f)
        y += line_height
        
    out_path = os.path.join(output_dir, "fig2b_git_commit_history_terminal.png")
    img.save(out_path, quality=95)
    print(f"Saved: {out_path}")

# -------------------------------------------------------------
# IMAGE 2: fig2c_pr_governance_and_precommit.png
# -------------------------------------------------------------
def render_pr_governance():
    width = 2100
    height = 980
    
    img = Image.new("RGBA", (width, height), (15, 23, 42, 255))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([0, 0, width-1, height-1], radius=16, fill=(11, 15, 25, 255), outline=(51, 65, 85, 255), width=2)
    
    # Left Card: PR Template
    left_w = 1010
    draw.rounded_rectangle([24, 20, left_w+24, height-24], radius=12, fill=(17, 24, 39, 255), outline=(55, 65, 81, 255), width=2)
    draw.rounded_rectangle([24, 20, left_w+24, 70], radius=12, fill=(31, 41, 55, 255))
    draw.rectangle([24, 54, left_w+24, 70], fill=(31, 41, 55, 255))
    draw.ellipse([44, 36, 56, 48], fill=(239, 68, 68, 255))
    draw.ellipse([64, 36, 76, 48], fill=(245, 158, 11, 255))
    draw.ellipse([84, 36, 96, 48], fill=(34, 197, 94, 255))
    draw.text((116, 32), "[PULL REQUEST TEMPLATE] .github/pull_request_template.md", fill=(148, 163, 184, 255), font=font_title)
    
    left_lines = [
        [("## OmniPay Pull Request Governance Specification", (56, 189, 248, 255), True)],
        [("<!-- Enforce Lean Small-Batch Flow: Max 300 Lines of Code Change -->", (100, 116, 139, 255), False)],
        [("**Issue Tracking:** Ref: JIRA-OMNI-# / Fixes #__", (226, 232, 240, 255), False)],
        [("**Branch Naming:** `feature/<module>` | `fix/<bug-id>`", (226, 232, 240, 255), False)],
        [],
        [("### 1. Delivery & Architectural Summary", (251, 191, 36, 255), True)],
        [("- [ ] Implements zero-downtime backward-compatible API route", (203, 213, 225, 255), False)],
        [("- [ ] Schema changes follow Expand-and-Contract (Parallel Run)", (203, 213, 225, 255), False)],
        [("- [ ] OpenAPI / Swagger documentation updated and verified", (203, 213, 225, 255), False)],
        [],
        [("### 2. Automated Quality & Shift-Left Verification", (251, 191, 36, 255), True)],
        [("[x] Flake8 Linting: 100% PEP-8 compliant (0 errors, 0 warnings)", (74, 222, 128, 255), False)],
        [("[x] Bandit SAST: Zero High/Medium security flaws detected", (74, 222, 128, 255), False)],
        [("[x] Gitleaks Secret Detection: Zero credentials/keys in diff", (74, 222, 128, 255), False)],
        [("[x] Pytest Automated Suite: 100% Pass Rate (Unit + Integration)", (74, 222, 128, 255), False)],
        [("[x] Code Coverage Quality Gate: >= 85% (Actual: 92% Branch Cov)", (74, 222, 128, 255), False)],
        [("[x] Trivy Container Vulnerability Scan: Zero Critical/High CVEs", (74, 222, 128, 255), False)],
        [],
        [("### 3. Peer Review & Governance Sign-Off (PCI-DSS Audit)", (251, 191, 36, 255), True)],
        [("- Mandatory Reviewers: >= 1 Qualified Senior Peer Reviewer", (248, 113, 113, 255), False)],
        [("- Branch Protection: Direct push to main cryptographically blocked", (248, 113, 113, 255), False)],
        [("- Merge Strategy: Squash and Merge (Enforces linear Git history)", (56, 189, 248, 255), False)],
        [("- Cryptographic Traceability: GPG-signed commit required", (244, 114, 182, 255), False)],
    ]
    
    y = 86
    for segs in left_lines:
        if not segs:
            y += 12
            continue
        x = 44
        for text, color, is_b in segs:
            f = font_bold if is_b else font_reg
            draw.text((x, y), text, fill=color, font=f)
            x += draw.textlength(text, font=f)
        y += 34

    # Right Card: Pre-commit & Hook Execution
    right_x = left_w + 56
    right_w = width - right_x - 24
    draw.rounded_rectangle([right_x, 20, right_x+right_w, height-24], radius=12, fill=(17, 24, 39, 255), outline=(55, 65, 81, 255), width=2)
    draw.rounded_rectangle([right_x, 20, right_x+right_w, 70], radius=12, fill=(31, 41, 55, 255))
    draw.rectangle([right_x, 54, right_x+right_w, 70], fill=(31, 41, 55, 255))
    draw.ellipse([right_x+20, 36, right_x+32, 48], fill=(239, 68, 68, 255))
    draw.ellipse([right_x+40, 36, right_x+52, 48], fill=(245, 158, 11, 255))
    draw.ellipse([right_x+60, 36, right_x+72, 48], fill=(34, 197, 94, 255))
    draw.text((right_x+92, 32), "[GIT HOOKS] .pre-commit-config.yaml & Shift-Left Run", fill=(148, 163, 184, 255), font=font_title)
    
    right_lines = [
        [("# OmniPay Shift-Left Pre-Commit Policy", (100, 116, 139, 255), False)],
        [("repos:", (147, 197, 253, 255), True)],
        [("  - repo: https://github.com/pre-commit/pre-commit-hooks", (226, 232, 240, 255), False)],
        [("    rev: v4.4.0", (251, 191, 36, 255), False)],
        [("    hooks:", (147, 197, 253, 255), False)],
        [("      - id: check-yaml", (74, 222, 128, 255), False)],
        [("      - id: end-of-file-fixer", (74, 222, 128, 255), False)],
        [("      - id: trailing-whitespace", (74, 222, 128, 255), False)],
        [("  - repo: https://github.com/pycqa/flake8", (226, 232, 240, 255), False)],
        [("    rev: 6.1.0", (251, 191, 36, 255), False)],
        [("    hooks:", (147, 197, 253, 255), False)],
        [("      - id: flake8", (74, 222, 128, 255), False)],
        [("        args: ['--max-line-length=127']", (251, 146, 60, 255), False)],
        [("  - repo: https://github.com/PyCQA/bandit", (226, 232, 240, 255), False)],
        [("    rev: 1.7.5", (251, 191, 36, 255), False)],
        [("    hooks:", (147, 197, 253, 255), False)],
        [("      - id: bandit", (74, 222, 128, 255), False)],
        [("        args: ['-r', 'app/', '-ll', '-ii']", (251, 146, 60, 255), False)],
        [],
        [("# Local Pre-Commit Hook Execution Output:", (100, 116, 139, 255), True)],
        [("$ pre-commit run --all-files", (56, 189, 248, 255), True)],
        [("Check Yaml Configuration................................Passed", (74, 222, 128, 255), False)],
        [("Trim Trailing Whitespace................................Passed", (74, 222, 128, 255), False)],
        [("Flake8 PEP-8 Code Quality Linter........................Passed", (74, 222, 128, 255), False)],
        [("Bandit Static Application Security Testing (SAST).......Passed", (74, 222, 128, 255), False)],
        [("[SUCCESS] 100% Pre-Commit Shift-Left Quality Checks Passed", (34, 197, 94, 255), True)]
    ]
    
    y = 86
    for segs in right_lines:
        if not segs:
            y += 10
            continue
        x = right_x + 20
        for text, color, is_b in segs:
            f = font_bold if is_b else font_reg
            draw.text((x, y), text, fill=color, font=f)
            x += draw.textlength(text, font=f)
        y += 34
        
    out_path = os.path.join(output_dir, "fig2c_pr_governance_and_precommit.png")
    img.save(out_path, quality=95)
    print(f"Saved: {out_path}")

# -------------------------------------------------------------
# IMAGE 3: fig2d_branch_protection_terminal.png
# -------------------------------------------------------------
def render_branch_protection():
    width = 2100
    height = 680
    img, draw = create_terminal_base(width, height, "TERMINAL: Branch Protection Policy Enforcement & Direct Push Prevention (PowerShell)")
    
    lines = [
        [("(.venv) PS C:\\Works\\OmniPay\\devops-delivery-artefacts> ", (56, 189, 248, 255), True), 
         ("git branch -vv", (250, 204, 21, 255), True)],
        
        [("* ", (74, 222, 128, 255), True),
         ("main               ", (74, 222, 128, 255), True),
         ("9035bdf ", (250, 204, 21, 255), True),
         ("[origin/main] ", (56, 189, 248, 255), True),
         ("Merge PR #4: CI/CD & Terraform IaC (Protected: Fast-Forward/Squash)", (226, 232, 240, 255), False)],
        
        [("  feature/auth-jwt   ", (148, 163, 184, 255), False),
         ("d2fa2b2 ", (250, 204, 21, 255), True),
         ("[origin/feature/auth-jwt: gone] ", (248, 113, 113, 255), False),
         ("(Merged & Deleted - Short-Lived Feature Branch)", (100, 116, 139, 255), False)],
        
        [("  feature/docker-pkg ", (148, 163, 184, 255), False),
         ("763e1dc ", (250, 204, 21, 255), True),
         ("[origin/feature/docker-pkg: gone] ", (248, 113, 113, 255), False),
         ("(Merged & Deleted - Short-Lived Feature Branch)", (100, 116, 139, 255), False)],
        
        [], # blank line
        
        [("(.venv) PS C:\\Works\\OmniPay\\devops-delivery-artefacts> ", (56, 189, 248, 255), True), 
         ("git push origin main --force", (250, 204, 21, 255), True)],
        
        [("Total 0 (delta 0), reused 0 (delta 0)", (148, 163, 184, 255), False)],
        [("remote: error: GH006: Protected branch update failed for refs/heads/main.", (239, 68, 68, 255), True)],
        [("remote: error: At least 1 approving review required from code owners.", (239, 68, 68, 255), False)],
        [("remote: error: Required status check 'CI/CD DevSecOps Quality Gate' has not passed.", (239, 68, 68, 255), False)],
        [("remote: error: Direct force-pushes to main are strictly prohibited by Branch Protection Policy.", (239, 68, 68, 255), True)],
        [("To https://github.com/omnipay-enterprise/core-payment-api.git", (226, 232, 240, 255), False)],
        [(" ! [remote rejected] main -> main (protected branch hook declined)", (248, 113, 113, 255), True)],
        [("error: failed to push some refs to 'https://github.com/omnipay-enterprise/core-payment-api.git'", (239, 68, 68, 255), True)]
    ]
    
    y = 80
    line_height = 36
    for segs in lines:
        if not segs:
            y += 16
            continue
        x = 36
        for text, color, is_b in segs:
            f = font_bold if is_b else font_reg
            draw.text((x, y), text, fill=color, font=f)
            x += draw.textlength(text, font=f)
        y += line_height
        
    out_path = os.path.join(output_dir, "fig2d_branch_protection_terminal.png")
    img.save(out_path, quality=95)
    print(f"Saved: {out_path}")

render_git_commit_history()
render_pr_governance()
render_branch_protection()
print("All version control images rendered successfully.")
