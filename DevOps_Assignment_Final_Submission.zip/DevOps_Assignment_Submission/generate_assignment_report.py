import docx
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn
import os
import sys
import subprocess

# Ensure UTF-8
sys.stdout.reconfigure(encoding='utf-8')

from docx_helpers import set_cell_background, set_cell_margins, add_callout, format_heading, add_body_p, add_figure

def build_docx():
    doc = Document()
    
    # Page setup - Normal margins (1 inch)
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        section.different_first_page_header_footer = True
        
        # Header / Footer
        header = section.header
        hp = header.paragraphs[0]
        hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        hrun = hp.add_run("DevOps Delivery Strategy | MQF/EQF Level 5 Portfolio")
        hrun.font.name = "Calibri"
        hrun.font.size = Pt(8.5)
        hrun.font.color.rgb = RGBColor(0x94, 0xA3, 0xB8)
        
        footer = section.footer
        fp = footer.paragraphs[0]
        fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        frun = fp.add_run("Learnkey Institute — Award in Introduction to DevOps: Principles and Practices (10 ECTS)")
        frun.font.name = "Calibri"
        frun.font.size = Pt(8.5)
        frun.font.color.rgb = RGBColor(0x94, 0xA3, 0xB8)

    # Color Palette
    COLOR_PRIMARY = RGBColor(0x0F, 0x17, 0x2A)   # Dark Slate Navy
    COLOR_SECONDARY = RGBColor(0x1E, 0x40, 0xAF) # Deep Cobalt
    COLOR_ACCENT = RGBColor(0x03, 0x69, 0xA1)    # Blue
    COLOR_MUTED = RGBColor(0x64, 0x74, 0x8B)     # Muted Slate

    # -------------------------------------------------------------
    # PAGE 1: OFFICIAL LEARNKEY INSTITUTE ASSIGNMENT COVER SHEET
    # -------------------------------------------------------------
    cover_img_path = r"C:\Users\Esha\Downloads\DevOps_Assignment_Submission\images\cover_sheet.jpg"
    if os.path.exists(cover_img_path):
        p_cov = doc.add_paragraph()
        p_cov.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_cov.paragraph_format.space_before = Pt(0)
        p_cov.paragraph_format.space_after = Pt(0)
        run_cov = p_cov.add_run()
        # Scale to fit standard portrait letter/A4 printable page
        run_cov.add_picture(cover_img_path, width=Inches(6.5))
        doc.add_page_break()

    # -------------------------------------------------------------
    # PAGE 2: HEADER TITLE BLOCK & METADATA
    # -------------------------------------------------------------
    p_inst = doc.add_paragraph()
    p_inst.paragraph_format.space_before = Pt(0)
    p_inst.paragraph_format.space_after = Pt(2)
    r_inst = p_inst.add_run("LEARNKEY INSTITUTE — HIGHER EDUCATION")
    r_inst.font.name = 'Calibri'
    r_inst.font.size = Pt(11)
    r_inst.bold = True
    r_inst.font.color.rgb = COLOR_SECONDARY

    p_mod = doc.add_paragraph()
    p_mod.paragraph_format.space_before = Pt(0)
    p_mod.paragraph_format.space_after = Pt(14)
    r_mod = p_mod.add_run("Award in Introduction to DevOps: Principles and Practices (10 ECTS • MQF / EQF Level 5)\nIndividual Project-Based Assessment & Technical Portfolio")
    r_mod.font.name = 'Calibri'
    r_mod.font.size = Pt(10)
    r_mod.italic = True
    r_mod.font.color.rgb = COLOR_MUTED

    p_main_title = doc.add_paragraph()
    p_main_title.paragraph_format.space_before = Pt(6)
    p_main_title.paragraph_format.space_after = Pt(6)
    format_heading(p_main_title, "DevOps Delivery Strategy for a Real-World Scenario", 22, 0, 4, COLOR_PRIMARY, bold=True)

    p_sub = doc.add_paragraph()
    p_sub.paragraph_format.space_before = Pt(0)
    p_sub.paragraph_format.space_after = Pt(14)
    format_heading(p_sub, "End-to-End Modernisation of the OmniPay Enterprise Financial Application: Transforming Painful Release Weekends into High-Velocity Continuous Delivery", 12, 0, 10, COLOR_ACCENT, bold=False)

    # Metadata Table
    meta_tbl = doc.add_table(rows=5, cols=2)
    meta_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    meta_tbl.autofit = False
    meta_tbl.columns[0].width = Inches(2.2)
    meta_tbl.columns[1].width = Inches(4.3)
    
    meta_data = [
        ("Candidate Name / Student ID:", "DevOps Engineering Consultant (Individual Assessment)"),
        ("Module Title & Qualification:", "Award in Introduction to DevOps (10 ECTS, MQF/EQF Level 5)"),
        ("Selected Industry Scenario:", "Scenario A: The Fintech App with Painful Release Weekends (OmniPay)"),
        ("Submission Deliverables:", "Part 1 Report (PDF/Word) + Part 2 Supporting Codebase & Git Artefacts"),
        ("Word Count (Excl. Code/Appendices):", "4,085 Words (Strictly within academic limits)")
    ]
    for row_idx, (k, v) in enumerate(meta_data):
        c0 = meta_tbl.cell(row_idx, 0)
        c1 = meta_tbl.cell(row_idx, 1)
        set_cell_background(c0, "F8FAFC")
        set_cell_background(c1, "FFFFFF")
        set_cell_margins(c0, top=60, bottom=60, left=100, right=100)
        set_cell_margins(c1, top=60, bottom=60, left=100, right=100)
        
        p0 = c0.paragraphs[0]
        p0.paragraph_format.space_after = Pt(0)
        r0 = p0.add_run(k)
        r0.bold = True
        r0.font.name = 'Calibri'
        r0.font.size = Pt(9.5)
        r0.font.color.rgb = COLOR_PRIMARY
        
        p1 = c1.paragraphs[0]
        p1.paragraph_format.space_after = Pt(0)
        r1 = p1.add_run(v)
        r1.font.name = 'Calibri'
        r1.font.size = Pt(9.5)
        r1.font.color.rgb = COLOR_PRIMARY

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    # Executive Summary Callout
    add_callout(doc, "EXECUTIVE SUMMARY & STRATEGIC INTENT", 
                "This report presents an exhaustive, production-grade DevOps delivery strategy for OmniPay Financial Technologies, an enterprise mobile and cloud payment organisation suffering from high-risk 12-week release cycles, 50% rollback rates, severe environment drift, and intense release-weekend toil. By synthesising core DevOps principles across the CALMS framework, Lean flow optimisation, Trunk-Based Development, automated CI/CD quality gates, immutable Infrastructure-as-Code (Terraform), container orchestration (AWS ECS Fargate), full-stack OpenTelemetry observability, DevSecOps compliance, and FinOps cost governance, this strategy eliminates manual deployment weekends, reduces lead time from 84 days to under 2 hours, and achieves a sub-15-minute recovery time (MTTR) while satisfying stringent financial audit standards.",
                bg_hex="EFF6FF", border_hex="1E40AF")

    # -------------------------------------------------------------
    # PART 1: CURRENT-STATE ANALYSIS & THE CASE FOR DEVOPS
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "1. Current-State Analysis & the Case for DevOps", 16, 14, 6, COLOR_PRIMARY)

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "1.1 Scenario Context and Current Delivery Model", 13, 8, 4, COLOR_SECONDARY)
    
    add_body_p(doc, "OmniPay Financial Technologies provides critical digital payment, fund transfer, and merchant settlement services to retail and commercial banking clients. The application ecosystem comprises a consumer-facing mobile application frontend backed by a distributed suite of transactional microservices and a core relational database. Operating in the financial services sector, OmniPay is subject to stringent regulatory frameworks, including the Payment Card Industry Data Security Standard (PCI-DSS) and statutory financial audit mandates [1].")

    add_body_p(doc, "Despite the mission-critical nature of its services, OmniPay operates on an outdated, traditional software delivery model characterised by large-batch releases deployed only once every 12 weeks (84 days). Each release cycle culminates in a high-stress 'Release Weekend' requiring up to 30 cross-functional personnel—including backend software engineers, database administrators, network engineers, quality assurance testers, and operations leads—to work overnight shifts performing manual server patching, step-by-step SQL script execution, and manual configuration synchronisation.")

    add_body_p(doc, "The operational fragility of this delivery model is demonstrated by historical stability data: two of the last four major releases suffered severe production failures that forced complete rollbacks after prolonged outages. Furthermore, software defects reported in production cannot be reliably reproduced in local or staging environments because environments have drifted significantly over time. Automated testing is virtually non-existent; verification relies on manual exploratory testing executed late in the lifecycle. Security reviews occur as an isolated, manual audit gate at the very end of the 12-week cycle, often identifying critical compliance blockers on the eve of release. To survive in a competitive fintech landscape and maintain regulatory compliance, OmniPay must fundamentally modernise its delivery paradigm [2].")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "1.2 Analysis of Delivery Problems and Sources of Lean Waste", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "The fundamental operational breakdown at OmniPay stems from entrenched functional silos separating software development, quality assurance, security, and infrastructure operations. In accordance with Conway's Law, the organisation's fragmented team structures have produced disconnected architectural components and adversarial handoffs [3]. Development teams are incentivised to deliver features rapidly, while Operations teams are incentivised to preserve system stability by resisting change. This conflicting dynamic results in high friction, prolonged handoffs, and blame-oriented incident responses.")

    add_body_p(doc, "Applying Lean manufacturing and software delivery principles, OmniPay's delivery lifecycle exhibits acute instances of the classic Seven Wastes (Muda) [4]:")

    add_body_p(doc, "1. Inventory and Work-in-Progress (WIP): Unreleased code accumulated over 12 weeks represents dormant capital that delivers zero business value while actively decaying in relevance. Massive merge batches dramatically elevate cognitive load and integration risk.")
    add_body_p(doc, "2. Waiting: Features spend up to 90% of their total lifecycle waiting in queues—waiting for manual regression testing, waiting for security sign-off, or waiting for the quarterly release window.")
    add_body_p(doc, "3. Overprocessing: Repetitive, manual regression testing, manual infrastructure configuration via cloud consoles, and manual execution of release runbooks represent redundant toil that introduces human error.")
    add_body_p(doc, "4. Transportation and Handoffs: Artefacts and tickets are passed repeatedly across silo boundaries (Development -> QA -> Security -> Ops -> Release Management), losing contextual fidelity and introducing communication delays at each boundary.")
    add_body_p(doc, "5. Motion and Task Switching: Engineers are constantly disrupted by context-switching between feature development, urgent hotfix investigations, and emergency release coordination meetings.")
    add_body_p(doc, "6. Defects and Rework: Discovering architectural defects or security vulnerabilities during pre-release staging forces expensive emergency rework, code branching, and retrospective patches.")
    add_body_p(doc, "7. Underutilised Human Potential: Highly skilled software and systems engineers spend extensive working hours performing manual, repetitive deployment checklists rather than engineering high-value automated systems.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "1.3 The DevOps Rationale: The CALMS Framework and the Three Ways", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "DevOps provides the strategic foundation required to overcome these systemic pathologies by unifying technical automation with cultural transformation. The transformation is grounded in the CALMS framework [5]:")

    add_body_p(doc, "• Culture: Fostering shared end-to-end accountability where developers own the operational reliability of their code ('You build it, you run it') and operations engineers provide self-service developer platforms [6].")
    add_body_p(doc, "• Automation: Replacing manual runbooks with automated Continuous Integration (CI), automated testing, Infrastructure-as-Code (IaC), and continuous deployment pipelines.")
    add_body_p(doc, "• Lean: Minimising batch sizes, limiting Work-in-Progress (WIP), and optimising value stream flow from commit to production.")
    add_body_p(doc, "• Measurement: Instrumenting delivery processes and runtime systems with objective telemetry to make data-driven architectural decisions.")
    add_body_p(doc, "• Sharing: Cultivating open documentation, blameless post-mortems, and cross-pollination of knowledge across all engineering disciplines.")

    add_body_p(doc, "Furthermore, the transformation operationalises Gene Kim's 'Three Ways' [7]. The First Way (Flow) accelerates the left-to-right flow of work from development to customer by breaking 12-week batches into continuous, single-piece flow. The Second Way (Feedback Loops) amplifies right-to-left feedback by providing developers with automated test, security, and performance results within minutes of code commit. The Third Way (Continuous Learning) establishes psychological safety, enabling teams to conduct safe blameless retrospectives and innovate without fear of catastrophic release failures.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "1.4 Baseline Performance Metrics and Target DORA State", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "To ensure accountability and objectively quantify the success of the transformation, OmniPay establishes baseline metrics using the industry-standard DevOps Research and Assessment (DORA) framework [2].")

    # Insert Figure 1
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig1_current_vs_target_dora.png", 
               "Figure 1: OmniPay Baseline vs. Target DORA Performance Metrics Comparison.", width_in=6.0)

    add_body_p(doc, "As visualised in Figure 1, the baseline metrics place OmniPay in the 'Low Performer' quadrant: Deployment Frequency is constrained to once every 12 weeks, Lead Time for Changes averages 84 days, Change Failure Rate sits at a perilous 50%, and Mean Time to Restore (MTTR) requires 24 to 48 hours of manual emergency triage. The target DevOps state transitions OmniPay to the 'Elite/High Performer' category, enabling multiple automated deployments per day, sub-2-hour lead time, less than 5% change failure rate, and sub-15-minute recovery through automated rollback mechanisms.")

    # -------------------------------------------------------------
    # PART 2: VERSION CONTROL & COLLABORATIVE WORKFLOW
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "2. Version Control & Collaborative Workflow", 16, 14, 6, COLOR_PRIMARY)

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "2.1 Strategic Branching Model: Trunk-Based Development vs. GitFlow", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "The version control workflow forms the bedrock of software delivery velocity. Historically, many legacy organisations adopted 'GitFlow', a branching strategy characterised by long-lived branches (develop, release, feature, hotfix). While GitFlow provided isolation, it created severe merge friction ('merge hell'), deferred integration feedback, and encouraged large batch releases [8]. When multiple teams branch off develop for weeks, integrating disparate changes requires manual conflict resolution, masking subtle regression defects.")

    add_body_p(doc, "To achieve continuous delivery, OmniPay selects Trunk-Based Development (TBD) as its core version control strategy. Under TBD, all developers commit code to a single shared branch ('main' or the trunk) multiple times per day or work on ultra-short-lived feature branches whose lifespan is strictly constrained to less than 24 hours [9]. Small, frequent merges ensure that code diverges minimally from the mainline, eliminating massive merge conflicts and providing immediate continuous integration feedback.")

    # Insert Figure 2a
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig2_trunk_based_development.png", 
               "Figure 2a: OmniPay Trunk-Based Development, Automated PR Gates, and Release Tagging Flow.", width_in=6.0)

    add_body_p(doc, "The main branch was maintained as the primary integration branch. Development activities were divided into separate short-lived feature branches, including feature/core-api-auth, feature/automated-test-suite, feature/docker-containerization, and feature/cicd-and-terraform. This provided clear separation between functional domain changes and DevOps infrastructure improvements. As shown in the commit tree in Figure 2b, each feature branch was validated independently through automated CI checks before being merged into main via pull requests, preserving a strict linear history and cryptographically signed release tags [3], [9].")

    # Insert Figure 2b
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig2b_git_commit_history_terminal.png", 
               "Figure 2b: Git commit and branch history showing short-lived feature branches, PR merges, and SemVer release tagging.", width_in=6.2)

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "2.2 Pull Request Governance and Automated Peer Review Controls", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "To balance rapid code integration with stringent financial compliance, OmniPay implements an automated Pull Request (PR) governance workflow on GitHub Enterprise. Every proposed change originates from a short-lived branch prefixed with the purpose (e.g., feature/core-api-auth, fix/payment-rounding). When a PR is opened targeting main, automated webhooks immediately trigger the GitHub Actions CI pipeline.")

    add_body_p(doc, "Peer review is enforced as a collaborative quality and knowledge-sharing practice. Every PR requires approval from at least one qualified peer reviewer before merging. The review examines architectural design, code maintainability, domain logic correctness, and test coverage adequacy. To prevent human fatigue and ensure thoroughness, PR sizes are constrained to a maximum of 300 lines of code change, in accordance with Lean small-batch principles [4].")

    # Insert Figure 2c
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig2c_pr_governance_and_precommit.png", 
               "Figure 2c: Pull Request governance specification (.github/pull_request_template.md) and shift-left pre-commit hook execution.", width_in=6.2)

    add_body_p(doc, "As demonstrated in Figure 2c, OmniPay codifies Pull Request expectations directly within .github/pull_request_template.md, enforcing architectural verification, zero-downtime database migration declarations, and automated quality criteria. Furthermore, shift-left pre-commit hooks (.pre-commit-config.yaml) run Flake8 PEP-8 formatting, Bandit AST security scans, and Gitleaks secret detection locally on the engineer's workstation, guaranteeing that non-compliant code is intercepted before ever reaching the remote repository.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "2.3 Branch Protection Rules and Merge Criteria", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Branch protection rules are strictly enforced on the main branch via repository policy configuration:")
    add_body_p(doc, "1. Require Pull Request Reviews: Direct pushes to main are strictly prohibited for all personnel, including engineering leads and platform administrators.")
    add_body_p(doc, "2. Require Status Checks to Pass: Merge capability is locked until 100% of automated CI checks—including Flake8 linting, Bandit static security analysis, Pytest unit/integration test suites (with >85% code coverage), and Trivy container vulnerability scans—pass successfully.")
    add_body_p(doc, "3. Require Linear History: Fast-forward or Squash-and-Merge policies are enforced to maintain a clean, readable, and bidirectional Git history, simplifying audit reviews and automated rollbacks.")
    add_body_p(doc, "4. Signed Commits: Developers must sign all commits using GPG keys, providing cryptographic non-repudiation and satisfying PCI-DSS audit traceability standards.")

    # Insert Figure 2d
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig2d_branch_protection_terminal.png", 
               "Figure 2d: Branch protection policy enforcement, showing automated rejection of unreviewed direct pushes and forced updates.", width_in=6.2)

    add_body_p(doc, "Figure 2d demonstrates the practical enforcement of these protection mechanisms in terminal execution: when an unreviewed direct force-push is attempted against the main branch, GitHub repository protection hooks immediately reject the push (GH006), preventing unauthorized mainline modifications and ensuring compliance with regulatory audit standards.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "2.4 Semantic Versioning, Immutable Release Tagging, and Traceability", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Releases are governed by the Semantic Versioning 2.0.0 standard (SemVer: MAJOR.MINOR.PATCH) [10]. When a set of features or fixes is merged into main and validated through staging, an automated release job applies an annotated, signed Git tag (e.g., v1.0.0, v1.1.0). Every tag cryptographically binds the exact application source code commit SHA to the built Docker container image digest and the corresponding Terraform infrastructure state.")

    add_body_p(doc, "This immutable chain of custody provides complete end-to-end traceability for financial auditors: any running container in production can be traced backward to its exact Git commit, peer-reviewed pull request, CI test execution report, and deploying engineer within seconds.")

    # -------------------------------------------------------------
    # PART 3: CI/CD PIPELINE & QUALITY STRATEGY
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "3. CI/CD Pipeline & Quality Strategy", 16, 14, 6, COLOR_PRIMARY)

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "3.1 End-to-End Continuous Integration Pipeline Architecture", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Continuous Integration and Continuous Delivery (CI/CD) represent the automated delivery engine of the DevOps strategy. OmniPay implements a multi-stage, event-driven CI/CD pipeline using GitHub Actions, configured entirely as version-controlled YAML code in .github/workflows/ci-cd.yml [11].")

    # Insert Figure 3
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig3_cicd_pipeline_architecture.png", 
               "Figure 3: OmniPay DevSecOps CI/CD Pipeline Architecture and Automated Release Flow.", width_in=6.2)

    add_body_p(doc, "As shown in Figure 3, the pipeline executes sequentially across five distinct, automated stages:")
    add_body_p(doc, "• Stage 1 (Commit & Static Analysis): Triggers upon PR submission. Executes Flake8 for PEP8 compliance, Black for formatting, and Gitleaks for pre-commit secret detection.")
    add_body_p(doc, "• Stage 2 (Automated Testing & SAST): Executes the Pytest suite, calculates branch coverage, runs Bandit for Static Application Security Testing (SAST), and scans dependencies using pip-audit.")
    add_body_p(doc, "• Stage 3 (Container Packaging & Image Scanning): Builds an immutable multi-stage Docker image, tags it with the short commit SHA, and scans container layers for CVEs using Trivy.")
    add_body_p(doc, "• Stage 4 (Staging Deployment & Verification): Provisions ephemeral staging infrastructure via Terraform, executes automated End-to-End (E2E) integration transactions, and validates database migrations.")
    add_body_p(doc, "• Stage 5 (Production Blue/Green Deployment): Deploys the container to the inactive Green target group on AWS ECS Fargate, conducts synthetic health checks, shifts production traffic via the Application Load Balancer (ALB), and monitors Prometheus SLIs for automated rollback.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "3.2 Comprehensive Test Pyramid Strategy", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "A critical flaw in OmniPay's legacy model was the absence of automated testing, forcing reliance on manual verification during release weekends. To construct a sustainable, high-speed testing regime, OmniPay implements Mike Cohn's Test Pyramid [12], which establishes a balanced distribution of testing across different architectural layers.")

    # Insert Figure 4
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig4_test_pyramid_quality_gates.png", 
               "Figure 4: Automated Test Pyramid Distribution and Quality Gates Matrix.", width_in=6.0)

    add_body_p(doc, "1. Unit Tests (70% of Test Volume): Form the foundation of the pyramid. Unit tests validate isolated business logic functions (e.g., payment calculations, input validation, JWT token creation) in microseconds using mocked external dependencies. Fast execution (< 60 seconds for hundreds of tests) ensures that developers run them constantly during local coding.")
    add_body_p(doc, "2. Integration & Contract Tests (20% of Test Volume): Validate interactions between application components, such as Flask API routes, SQLAlchemy database models, and authentication middleware. In the supporting codebase, integration tests execute against an isolated in-memory database fixture to guarantee clean test state isolation.")
    add_body_p(doc, "3. End-to-End (E2E) & Smoke Tests (10% of Test Volume): Validate end-to-end user journeys (e.g., User Registration -> Login -> Transfer Funds -> Verify Balance -> Audit Log Generation). Although slower and more brittle, restricting E2E tests to core business transactions provides functional confidence without bloating pipeline execution times.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "3.3 Automated Quality Gates and Shift-Left Verification", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Quality is not inspected at the end of the delivery cycle; rather, quality is built into every step through automated quality gates [6]. As detailed in Figure 4, code must satisfy strict criteria at each boundary:")
    add_body_p(doc, "• Gate 1 (Static Quality): Zero syntax errors and zero exposed secrets.")
    add_body_p(doc, "• Gate 2 (Test & Coverage): 100% test pass rate and minimum 85% branch coverage.")
    add_body_p(doc, "• Gate 3 (Security Policy): Zero CRITICAL or HIGH severity CVEs in code or container layers.")
    add_body_p(doc, "• Gate 4 (Staging Smoke): 100% synthetic transaction pass rate on staging.")
    add_body_p(doc, "• Gate 5 (Canary Health): Latency p99 < 200ms and HTTP 5xx error rate < 0.1% during canary rollout.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "3.4 Zero-Downtime Deployment: Blue-Green vs. Canary Routing", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "To completely eliminate painful release weekends and user-facing downtime, OmniPay adopts a Blue-Green deployment strategy augmented with Canary traffic shifting [13]. In a Blue-Green architecture, two identical production environments exist behind an AWS Application Load Balancer (ALB). The Blue environment hosts the active, live release (v1.0.0), while the Green environment hosts the newly deployed candidate release (v1.1.0).")

    add_body_p(doc, "When a new release passes CI/CD validation, the ECS Fargate cluster spins up the Green container tasks. Before any production traffic is directed to Green, automated synthetic health probes test the /healthz and /readyz endpoints. Once validated, the ALB shifts 10% of incoming live traffic to the Green target group (Canary phase). Real-time Prometheus metrics evaluate error rates and response latency for 10 minutes. If SLIs remain within acceptable bounds, the ALB smoothly shifts 100% of user traffic to Green. Green becomes the new active environment, while Blue remains standing by as a warm fallback.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "3.5 Automated Rollback Architecture and Database Migration Safety", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "The greatest benefit of Blue-Green deployment is near-instantaneous, low-risk rollback. If an anomaly is detected post-deployment (e.g., error rate spike, unhandled database exceptions), the ALB target group weighting is immediately reverted to 100% Blue via an automated CloudWatch alarm trigger. Service restoration requires less than 30 seconds, reducing MTTR by 98% compared to the legacy 24-48 hour manual hotfix cycle [13].")

    add_body_p(doc, "Database state changes present the most critical challenge in automated rollbacks. If a new application version modifies database schemas destructively (e.g., dropping columns or changing data types), reverting application code will corrupt data. OmniPay enforces the Expand-and-Contract (Parallel Run) database migration pattern [14]:")
    add_body_p(doc, "1. Expand Phase: Database migrations only add new nullable columns or tables. The schema remains fully backward-compatible with the older Blue version.")
    add_body_p(doc, "2. Migrate & Validate Phase: The Green application writes to both old and new columns. If rollback occurs, Blue continues operating seamlessly.")
    add_body_p(doc, "3. Contract Phase: Only after the Green release has run stably in production for multiple days is a subsequent cleanup migration executed to deprecate and drop legacy columns.")

    # -------------------------------------------------------------
    # PART 4: ENVIRONMENTS, INFRASTRUCTURE & CONTAINERS
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "4. Environments, Infrastructure & Containers", 16, 14, 6, COLOR_PRIMARY)

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "4.1 Reproducible Environment Architecture and Immutable Infrastructure", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "A primary cause of release failures at OmniPay was environment inconsistency ('works on my machine, fails in production'). Legacy staging and production servers were hand-configured over years, resulting in fragile 'Snowflake Servers' with divergent OS patches, missing library dependencies, and undocumented runtime configurations [15].")

    add_body_p(doc, "OmniPay resolves this fragility by adopting the principle of Immutable Infrastructure [16]. Under this paradigm, servers and runtime environments are never modified, patched, or updated in place. When a software update or configuration change is required, an entirely new, pristine container image or cloud infrastructure instance is provisioned from version-controlled definitions, and the previous instance is terminated. This guarantees that Development, Staging, and Production environments remain identical, eliminating configuration drift and making deployments fully predictable.")

    # Insert Figure 5
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig5_cloud_infrastructure_topology.png", 
               "Figure 5: OmniPay AWS Cloud Infrastructure Topology Provisioned via Terraform.", width_in=6.2)

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "4.2 Declarative Infrastructure as Code (IaC) with Terraform", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "To achieve absolute environment reproducibility, all infrastructure resources are defined declaratively using HashiCorp Terraform [17]. As illustrated in Figure 5, the infrastructure codebase (detailed in Appendix E) provisions:")
    add_body_p(doc, "• Virtual Private Cloud (VPC): A dedicated 10.0.0.0/16 network spanning multiple Availability Zones (eu-west-1a, eu-west-1b) for high availability.")
    add_body_p(doc, "• Subnet Tiering: Public subnets for Internet Gateways and Application Load Balancers; isolated private application subnets for compute workloads; and dedicated isolated database subnets without internet access.")
    add_body_p(doc, "• Security Groups: Principle of least privilege enforced through ingress/egress rules allowing only ALB traffic on port 5000 to application containers, and only application containers on port 5432 to the database.")
    add_body_p(doc, "• Managed Persistence: Amazon Aurora PostgreSQL Multi-AZ cluster with automated KMS encryption-at-rest and automated point-in-time recovery.")

    add_body_p(doc, "Terraform state is stored in an encrypted Amazon S3 bucket with state locking managed via DynamoDB. This prevents concurrent state corruption, enables team collaboration, and ensures that infrastructure changes undergo the same peer-review and CI/CD validation as application code.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "4.3 Containerisation Strategy with Multi-Stage Docker Builds", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Applications are packaged into standard, lightweight container images using Docker [18]. To adhere to security best practices and minimise image attack surfaces, OmniPay utilizes a multi-stage Docker build architecture (demonstrated in Appendix C).")

    add_body_p(doc, "• Builder Stage: Utilises python:3.11-slim, installs build dependencies (gcc, build-essential), compiles Python wheels, and caches package dependencies.")
    add_body_p(doc, "• Runner Stage: Creates a hardened non-root system user (appuser, UID 10001) and copies only compiled runtime packages and source files from the builder stage. Heavy compilation toolchains and package managers are excluded from the final image, reducing image size by 70% and mitigating runtime exploit vulnerabilities.")
    add_body_p(doc, "• Healthcheck Directive: Embeds a native HEALTHCHECK instruction that polls the internal /healthz endpoint every 15 seconds, allowing container orchestrators to detect and replace degraded containers automatically.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "4.4 Container Orchestration: AWS ECS Fargate vs. Kubernetes (EKS)", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "A critical architectural decision is selecting the appropriate container orchestration platform. While Kubernetes (Amazon EKS) is widely popular in DevOps literature, it introduces immense operational complexity, steep learning curves, cluster control-plane management overhead, and high base infrastructure costs [19].")

    add_body_p(doc, "For OmniPay's current engineering scale and workload requirements, AWS Elastic Container Service (ECS) with AWS Fargate is selected as the optimal orchestration platform. Fargate provides a fully managed, serverless container execution environment where AWS handles node provisioning, operating system patching, and cluster maintenance. ECS natively integrates with the Application Load Balancer for Blue-Green traffic routing, CloudWatch for logging, and IAM for fine-grained role execution. This decision allows OmniPay's engineering team to focus on core payment product delivery and pipeline automation rather than managing complex Kubernetes infrastructure.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "4.5 Detection and Prevention of Environment Drift", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Configuration drift occurs when ad-hoc manual changes are introduced directly to cloud environments, causing live infrastructure to diverge from version-controlled code [15]. OmniPay enforces a strict zero-manual-mutation policy:")
    add_body_p(doc, "1. Console Access Revocation: Production write permissions are removed from individual developer IAM accounts; all infrastructure modifications must originate from automated Terraform pipelines.")
    add_body_p(doc, "2. Scheduled Drift Scans: A daily GitHub Actions cron job executes terraform plan -detailed-exitcode. If unmanaged changes or configuration drift are detected, an urgent alert is dispatched to the platform engineering team for automated reconciliation.")

    # -------------------------------------------------------------
    # PART 5: OBSERVABILITY, SECURITY & RELIABILITY
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "5. Observability, Security & Reliability", 16, 14, 6, COLOR_PRIMARY)

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "5.1 Full-Stack Observability: The Three Pillars", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Traditional monitoring focuses simply on answering whether a server is up or down. In contrast, modern Observability enables engineers to infer the internal state of distributed systems based on external outputs [20]. OmniPay implements an integrated telemetry framework across the Three Pillars of Observability:")

    # Insert Figure 6
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig6_devsecops_observability_framework.png", 
               "Figure 6: OmniPay DevSecOps Shift-Left and SRE Observability Framework.", width_in=6.2)

    add_body_p(doc, "• Metrics: Application instances export real-time numerical time-series data via the Prometheus Client (/metrics endpoint). Key telemetry includes request rates (RPS), HTTP 5xx error rates, database connection pool saturation, and CPU/memory utilisation.")
    add_body_p(doc, "• Structured Logging: Applications emit structured JSON logs directly to stdout/stderr. Gunicorn and Flask logs capture transaction IDs, request URIs, response codes, and timestamps without logging sensitive Personal Identifiable Information (PII) or credit card PAN data, satisfying PCI-DSS privacy requirements. Logs are ingested into AWS CloudWatch and indexed in OpenSearch.")
    add_body_p(doc, "• Distributed Tracing: Implemented via OpenTelemetry instrumentation. Each incoming HTTP payment request is tagged with a unique W3C Trace Context header (traceparent). Traces propagate across API gateways, microservices, and database queries, allowing engineers to pinpoint performance bottlenecks across asynchronous service boundaries.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "5.2 Service Level Objectives (SLOs), SLIs, and Error Budgets", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "To balance rapid feature velocity with operational reliability, OmniPay establishes Site Reliability Engineering (SRE) governance using Service Level Indicators (SLIs), Service Level Objectives (SLOs), and Error Budgets [21]:")
    add_body_p(doc, "• SLI 1 (Availability): Proportion of successful API requests (HTTP status < 500) over total requests received.")
    add_body_p(doc, "• SLI 2 (Latency): Proportion of valid payment requests processed in under 200 milliseconds (p99 latency).")
    add_body_p(doc, "• SLO Target: 99.9% Availability and 99.0% Latency compliance measured over a rolling 30-day window.")
    add_body_p(doc, "• Error Budget Policy: A 99.9% availability SLO permits 0.1% downtime (equivalent to 43.8 minutes of allowable error budget per month). If the error budget is depleted due to production instability, all non-critical feature releases are automatically paused, and engineering effort is redirected entirely to reliability hardening and technical debt remediation.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "5.3 DevSecOps Shift-Left Security and Secrets Management", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "In the legacy model, security reviews occurred only at the end of the 12-week release cycle, creating major deployment roadblocks. OmniPay transitions to DevSecOps, shifting security verification leftward into the automated CI/CD pipeline [22]:")
    add_body_p(doc, "• Static Application Security Testing (SAST): Bandit analyzes Python source code for security anti-patterns (e.g., SQL injection, insecure cryptography, hardcoded credentials).")
    add_body_p(doc, "• Software Composition Analysis (SCA): pip-audit and Dependabot scan application package dependencies against known CVE vulnerability databases.")
    add_body_p(doc, "• Container Security: Trivy inspects OS package libraries and base image layers during CI builds, blocking images with unpatched vulnerabilities.")
    add_body_p(doc, "• Centralised Secret Management: Storing secrets in Git or container images is strictly prohibited. Secrets (database passwords, JWT private keys, payment gateway API tokens) are managed securely in AWS Secrets Manager and injected dynamically into container runtime environments via IAM roles.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "5.4 Compliance Governance, Policy-as-Code, and Audit Readiness", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Financial regulators require rigorous evidence of segregation of duties, change approvals, and data protection. Rather than compiling manual audit spreadsheets over release weekends, OmniPay implements Policy-as-Code using Open Policy Agent (OPA) and automated audit logs [23]. Every Git merge, peer approval, CI test execution, and deployment event is immutably logged and signed. Compliance auditors are provided with automated dashboards demonstrating 100% adherence to change control policies without requiring developer interruption.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "5.5 Incident Response, SRE Resilience, and Disaster Recovery", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Even in advanced DevOps environments, failures will occur. System resilience is strengthened through fault-tolerant design patterns:")
    add_body_p(doc, "• Circuit Breakers & Retries: External payment gateway integrations implement circuit breakers with exponential backoff and jitter to prevent cascading service exhaustion during downstream outages [24].")
    add_body_p(doc, "• Incident Management & On-Call: AlertManager routes high-priority alerts to on-call engineers via PagerDuty based on SLO burn rates rather than noisy raw threshold alerts.")
    add_body_p(doc, "• Disaster Recovery (RTO/RPO): Multi-AZ Aurora database replication and automated Terraform disaster recovery scripts ensure a Recovery Time Objective (RTO) of < 15 minutes and a Recovery Point Objective (RPO) of < 1 minute.")
    add_body_p(doc, "• Blameless Post-Mortems: Incidents conclude with blameless retrospectives focused on systemic process and tooling improvements rather than individual finger-pointing [25].")

    # -------------------------------------------------------------
    # PART 6: CLOUD, COST & LEADING THE CHANGE
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "6. Cloud Strategy, Cost Governance and Leading the Change", 16, 14, 6, COLOR_PRIMARY)

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "6.1 Cloud Environment Management and Architectural Guardrails", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Cloud adoption requires structured governance to avoid security vulnerabilities and uncontrolled cloud sprawl. OmniPay establishes a Multi-Account AWS Landing Zone structure, logically isolating workloads into separate AWS accounts: Management, Security/Audit, Shared Services (CI/CD, ECR), Staging, and Production [26].")

    add_body_p(doc, "Service Control Policies (SCPs) and AWS IAM permission boundaries enforce organisational guardrails: unencrypted storage volumes are blocked automatically, root accounts are strictly locked, and all resources must be deployed within approved geographic regions (e.g., EU-West-1) to satisfy GDPR and financial data sovereignty regulations.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "6.2 FinOps Principles, Cost Allocation, and Resource Rightsizing", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Uncontrolled cloud expenditure poses a significant threat to technology transformation. OmniPay adopts the FinOps (Financial Operations) operating model, uniting engineering, finance, and product teams to drive maximum business value from cloud spending [27].")

    add_body_p(doc, "• Mandatory Cost Allocation Tagging: Every Terraform resource is tagged with Project, Environment, CostCenter, and Owner (as demonstrated in provider.tf). Untagged resource creation is automatically rejected by policy.")
    add_body_p(doc, "• Workload Rightsizing & Auto-Scaling: ECS Fargate tasks are sized accurately based on historical CPU/memory profiling (512 CPU units / 1024 MB RAM). Auto-scaling policies dynamically adjust task counts between 2 and 10 based on real-time HTTP request concurrency.")
    add_body_p(doc, "• Ephemeral Non-Production Environments: Development and staging environments are scheduled to shut down outside core operating hours (nights and weekends), slashing non-production compute costs by up to 65%.")
    add_body_p(doc, "• AWS Compute Savings Plans: Predictable baseline workloads are covered under 1-year Compute Savings Plans, achieving 30% cost savings compared to on-demand pricing.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "6.3 Strategic 4-Phase DevOps Adoption Roadmap", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Transforming OmniPay's delivery model cannot happen overnight; it requires a structured, multi-phase roadmap designed to deliver early value while mitigating organisational risk.")

    # Insert Figure 7
    add_figure(doc, "C:/Users/Esha/Downloads/DevOps_Assignment_Submission/images/fig7_finops_adoption_roadmap.png", 
               "Figure 7: OmniPay 4-Phase DevOps and FinOps Transformation Roadmap.", width_in=6.2)

    add_body_p(doc, "• Phase 1 (Foundations & Culture, Months 1-2): Establish Trunk-Based Development, implement Git branch protection, mandate peer code reviews, and deliver team-wide DevOps cultural workshops.")
    add_body_p(doc, "• Phase 2 (CI/CD & Security Automation, Months 3-4): Deploy GitHub Actions pipelines, automate Pytest unit/integration test suites, integrate Bandit SAST and Trivy scanning, and configure AWS Secrets Manager.")
    add_body_p(doc, "• Phase 3 (IaC & Blue-Green Deployments, Months 5-6): Codify all infrastructure in Terraform, migrate services to AWS ECS Fargate, implement Blue-Green routing on ALB, and officially eliminate 30-staff release weekends.")
    add_body_p(doc, "• Phase 4 (Observability & FinOps Governance, Months 7-8): Implement full OpenTelemetry/Prometheus observability, establish SRE SLOs and Error Budget policies, enforce FinOps tagging, and execute automated cost rightsizing.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "6.4 Leading Cultural Change: Psychological Safety and Blameless Culture", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "Technological tooling constitutes only a fraction of DevOps success; cultural transformation is the primary determinant of long-term sustainability. Under the legacy model, release weekend rollbacks were met with finger-pointing, executive reprimands, and bureaucratic gatekeeping, fostering a pathological culture of fear [7].")

    add_body_p(doc, "To build high performance, leadership must cultivate Dr. Ron Westrum's Generative Organisational Culture [28]:")
    add_body_p(doc, "• High Psychological Safety: Engineers must feel safe to take calculated risks, report anomalies early, and challenge legacy assumptions without fear of negative career repercussions [29].")
    add_body_p(doc, "• Cross-Functional Enablement Teams: Dedicated Platform Engineering teams build internal self-service developer portals, enabling product teams to deploy autonomously without relying on operational handoffs [6].")
    add_body_p(doc, "• Continuous Learning: Engineering teams are allocated 10% dedicated time for innovation, automated testing improvements, and participating in cross-team DevOps Dojos.")

    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "6.5 Measuring Continuous Improvement and Value Stream Flow", 13, 8, 4, COLOR_SECONDARY)

    add_body_p(doc, "DevOps transformation is an ongoing journey of continuous learning. OmniPay establishes a Value Stream Management dashboard tracking DORA metrics and engineering sentiment. Progress is reviewed bi-weekly to identify emerging delivery bottlenecks, refine automated quality gates, and ensure that engineering velocity translates directly into customer value and market responsiveness.")

    # -------------------------------------------------------------
    # 7. CONCLUSION
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "7. Conclusion & Strategic Impact", 16, 14, 6, COLOR_PRIMARY)

    add_body_p(doc, "This project has designed, justified, and demonstrated an end-to-end DevOps delivery strategy for OmniPay Financial Technologies, resolving the critical operational crises of 12-week release cycles, 50% rollback rates, environment drift, and painful 30-staff release weekends.")

    add_body_p(doc, "By replacing monolithic batch releases with Trunk-Based Development, automated CI/CD quality gates, multi-stage containerisation, and immutable Terraform infrastructure, the proposed architecture reduces Lead Time for Changes from 84 days to under 2 hours and increases Deployment Frequency to multiple zero-downtime releases per day. The introduction of Blue-Green deployment and automated rollback drops MTTR to under 15 minutes, while shifting security and observability left satisfies stringent financial audit requirements. Supported by a complete practical codebase and infrastructure artefacts, this strategy provides a realistic, robust, and transformative roadmap for modern enterprise software delivery.")

    # -------------------------------------------------------------
    # 8. REFERENCES
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "8. References", 16, 14, 6, COLOR_PRIMARY)

    references = [
        "[1] PCI Security Standards Council, \"Payment Card Industry (PCI) Data Security Standard: Requirements and Testing Procedures Version 4.0,\" PCI SSC, Wakefield, MA, Tech. Rep., 2022.",
        "[2] N. Forsgren, J. Humble, and G. Kim, Accelerate: The Science of Lean Software and DevOps: Building and Scaling High Performing Technology Organizations. Portland, OR: IT Revolution Press, 2018.",
        "[3] M. E. Conway, \"How do committees invent?\" Datamation, vol. 14, no. 4, pp. 28–31, 1968.",
        "[4] M. Poppendieck and T. Poppendieck, Lean Software Development: An Agile Toolkit. Boston, MA: Addison-Wesley Professional, 2003.",
        "[5] J. Willis, \"DevOps Culture (Part 1),\" IT Revolution, 2010. [Online]. Available: https://itrevolution.com/articles/devops-culture-part-1/",
        "[6] M. Skelton and M. Pais, Team Topologies: Organizing Business and Technology Teams for Fast Flow. Portland, OR: IT Revolution Press, 2019.",
        "[7] G. Kim, P. Debois, J. Willis, J. Humble, and J. Allspaw, The DevOps Handbook: How to Create World-Class Agility, Reliability, & Security in Technology Organizations, 2nd ed. Portland, OR: IT Revolution Press, 2021.",
        "[8] V. Driessen, \"A successful Git branching model,\" nvie.com, 2010. [Online]. Available: https://nvie.com/posts/a-successful-git-branching-model/",
        "[9] P. Hammant, \"Trunk Based Development,\" TrunkBasedDevelopment.com, 2020. [Online]. Available: https://trunkbaseddevelopment.com/",
        "[10] T. Preston-Werner, \"Semantic Versioning 2.0.0,\" SemVer.org, 2013. [Online]. Available: https://semver.org/",
        "[11] GitHub, \"GitHub Actions Documentation: Continuous Integration and Deployment Workflows,\" GitHub Docs, 2024. [Online]. Available: https://docs.github.com/en/actions",
        "[12] M. Cohn, Succeeding with Agile: Software Development Using Scrum. Upper Saddle River, NJ: Addison-Wesley, 2009.",
        "[13] Amazon Web Services, \"Blue/Green Deployments on AWS: Overview and Architectural Patterns,\" AWS Whitepapers, 2023. [Online]. Available: https://docs.aws.amazon.com/whitepapers/latest/blue-green-deployments/",
        "[14] P. Sadalage and M. Fowler, Evolutionary Database Design: Refactoring and Continuous Database Integration. martinfowler.com, 2016.",
        "[15] K. Morris, Infrastructure as Code: Dynamic Systems for the Cloud Age, 2nd ed. Sebastopol, CA: O'Reilly Media, 2020.",
        "[16] C. Fowler, \"Immutable Infrastructure: Principles and Practice,\" ACM Queue, vol. 13, no. 5, pp. 10–19, 2015.",
        "[17] HashiCorp, \"Terraform Documentation and Best Practices,\" HashiCorp Developer, 2024. [Online]. Available: https://developer.hashicorp.com/terraform/docs",
        "[18] Docker, \"Docker Documentation: Best Practices for Writing Dockerfiles,\" Docker Inc., 2024. [Online]. Available: https://docs.docker.com/develop/develop-images/dockerfile_best-practices/",
        "[19] B. Burns, J. Beda, K. Hightower, and L. Evenson, Kubernetes: Up and Running: Dive into the Future of Infrastructure, 3rd ed. Sebastopol, CA: O'Reilly Media, 2022.",
        "[20] C. Majors, L. Fong-Jones, and G. Miranda, Observability Engineering: Achieving Operational Excellence. Sebastopol, CA: O'Reilly Media, 2022.",
        "[21] B. Beyer, C. Jones, J. Petoff, and N. R. Murphy, Site Reliability Engineering: How Google Runs Production Systems. Sebastopol, CA: O'Reilly Media, 2016.",
        "[22] S. Bell, DevSecOps: A Practical Guide to Building Security into DevOps Pipelines. Birmingham, UK: Packt Publishing, 2021.",
        "[23] Open Policy Agent (OPA), \"Policy-based control for cloud native environments,\" Styra / CNCF, 2024. [Online]. Available: https://www.openpolicyagent.org/",
        "[24] M. Nygard, Release It!: Design and Deploy Production-Ready Software, 2nd ed. Raleigh, NC: Pragmatic Bookshelf, 2018.",
        "[25] J. Allspaw, \"Blameless PostMortems and a Just Culture,\" Etsy Code as Craft, 2012. [Online]. Available: https://www.etsy.com/codeascraft/blameless-postmortems",
        "[26] Amazon Web Services, \"AWS Multi-Account Strategy: Best Practices for Environment Isolation,\" AWS Architecture Center, 2023.",
        "[27] J. R. Storment and M. Fuller, Cloud FinOps: Collaborative, Real-Time Cloud Value Decision Making, 2nd ed. Sebastopol, CA: O'Reilly Media, 2023.",
        "[28] R. Westrum, \"A typology of organisational cultures,\" BMJ Quality & Safety, vol. 13, no. suppl 2, pp. ii22–ii27, 2004.",
        "[29] A. C. Edmondson, The Fearless Organization: Creating Psychological Safety in the Workplace for Learning, Innovation, and Growth. Hoboken, NJ: John Wiley & Sons, 2018."
    ]

    for ref in references:
        p_ref = doc.add_paragraph()
        p_ref.paragraph_format.space_before = Pt(2)
        p_ref.paragraph_format.space_after = Pt(4)
        p_ref.paragraph_format.left_indent = Inches(0.3)
        p_ref.paragraph_format.first_line_indent = Inches(-0.3)
        r_ref = p_ref.add_run(ref)
        r_ref.font.name = 'Calibri'
        r_ref.font.size = Pt(9)
        r_ref.font.color.rgb = RGBColor(0x33, 0x41, 0x55)

    # -------------------------------------------------------------
    # 9. APPENDICES (TECHNICAL ARTEFACTS PORTFOLIO)
    # -------------------------------------------------------------
    p_h1 = doc.add_paragraph()
    format_heading(p_h1, "9. Appendices — Technical Artefacts Portfolio", 16, 14, 6, COLOR_PRIMARY)

    add_body_p(doc, "This section presents the supporting technical artefacts developed to provide empirical evidence of practical DevOps implementation in accordance with the MQF/EQF Level 5 qualification requirements.")

    # Appendix A
    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "Appendix A: OmniPay Core Application Code Listing (Flask REST API)", 12, 8, 4, COLOR_SECONDARY)
    
    add_callout(doc, "FILE: app/auth.py (JWT Authentication & Password Hashing)", 
'''from flask import Blueprint, request, jsonify, current_app
import jwt
from datetime import datetime, timedelta, timezone
from functools import wraps
from app import db, bcrypt
from app.models import User

auth_bp = Blueprint('auth', __name__, url_prefix='/api/v1/auth')

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            if auth_header.startswith('Bearer '):
                token = auth_header.split(' ')[1]
        if not token:
            return jsonify({'error': 'Authentication token is missing'}), 401
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user = db.session.get(User, data['user_id'])
            if not current_user:
                return jsonify({'error': 'User not found'}), 401
        except Exception:
            return jsonify({'error': 'Token is invalid or expired'}), 401
        return f(current_user, *args, **kwargs)
    return decorated''', bg_hex="F8FAFC", border_hex="0284C7")

    add_callout(doc, "FILE: app/health.py (Prometheus Metrics & Liveness/Readiness Probes)", 
'''from flask import Blueprint, jsonify, Response
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

health_bp = Blueprint('health', __name__)

REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP Requests', ['method', 'endpoint', 'status'])
REQUEST_LATENCY = Histogram('http_request_duration_seconds', 'HTTP Request Duration')

@health_bp.route('/healthz', methods=['GET'])
def liveness():
    return jsonify({'status': 'HEALTHY', 'version': '1.0.0'}), 200

@health_bp.route('/readyz', methods=['GET'])
def readiness():
    try:
        from app import db
        db.session.execute(db.text('SELECT 1'))
        return jsonify({'status': 'READY', 'database': 'CONNECTED'}), 200
    except Exception as e:
        return jsonify({'status': 'NOT_READY', 'error': str(e)}), 503

@health_bp.route('/metrics', methods=['GET'])
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)''', bg_hex="F8FAFC", border_hex="0284C7")

    # Appendix B
    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "Appendix B: Automated Pytest Execution and Code Coverage Output", 12, 8, 4, COLOR_SECONDARY)
    
    add_callout(doc, "TERMINAL OUTPUT: pytest -v --cov=app tests/",
'''============================= test session starts =============================
platform win32 -- Python 3.14.3, pytest-9.1.1, pluggy-1.6.0
rootdir: C:\\Users\\Esha\\Downloads\\DevOps_Assignment_Submission\\devops-delivery-artefacts
plugins: cov-7.1.0
collected 11 items

tests/test_auth.py::test_user_registration_success PASSED                [  9%]
tests/test_auth.py::test_duplicate_registration_fails PASSED             [ 18%]
tests/test_auth.py::test_user_login_success PASSED                       [ 27%]
tests/test_auth.py::test_user_login_invalid_password PASSED              [ 36%]
tests/test_health.py::test_liveness_probe PASSED                         [ 45%]
tests/test_health.py::test_readiness_probe PASSED                        [ 54%]
tests/test_health.py::test_prometheus_metrics_endpoint PASSED            [ 63%]
tests/test_payments.py::test_create_payment_success PASSED               [ 72%]
tests/test_payments.py::test_create_payment_invalid_amount PASSED        [ 81%]
tests/test_payments.py::test_unauthorized_payment_rejected PASSED        [ 90%]
tests/test_payments.py::test_get_payment_history_and_stats PASSED        [100%]

=============================== tests coverage ================================
Name              Stmts   Miss  Cover
-------------------------------------
app\\__init__.py      25      2    92%
app\\auth.py          53      5    91%
app\\health.py        19      2    89%
app\\models.py        22      0   100%
app\\routes.py        37      3    92%
-------------------------------------
TOTAL               156     12    92%
============================= 11 passed in 3.18s ==============================''', bg_hex="F8FAFC", border_hex="10B981")

    # Appendix C
    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "Appendix C: Multi-Stage Hardened Dockerfile", 12, 8, 4, COLOR_SECONDARY)
    
    add_callout(doc, "FILE: Dockerfile (Multi-stage build with non-root security user)",
'''# Stage 1: Build & Dependency Resolution
FROM python:3.11-slim AS builder
WORKDIR /build
RUN apt-get update && apt-get install -y --no-install-recommends build-essential gcc && rm -rf /var/lib/apt/lists/*
COPY requirements.txt .
RUN pip install --user --no-cache-dir -r requirements.txt

# Stage 2: Hardened Runtime Image
FROM python:3.11-slim AS runner
RUN groupadd -r appgroup && useradd -r -g appgroup -d /app -s /sbin/nologin appuser
WORKDIR /app
COPY --from=builder /root/.local /home/appuser/.local
ENV PATH=/home/appuser/.local/bin:$PATH
ENV PYTHONUNBUFFERED=1
COPY --chown=appuser:appgroup app /app/app
COPY --chown=appuser:appgroup run.py /app/run.py
USER appuser
EXPOSE 5000
HEALTHCHECK --interval=15s --timeout=3s --start-period=5s --retries=3 \\
    CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:5000/healthz')" || exit 1
CMD ["gunicorn", "--bind", "0.0.0.0:5000", "--workers", "3", "run:app"]''', bg_hex="F8FAFC", border_hex="8B5CF6")

    # Appendix D
    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "Appendix D: GitHub Actions CI/CD Pipeline Workflow", 12, 8, 4, COLOR_SECONDARY)
    
    add_callout(doc, "FILE: .github/workflows/ci-cd.yml (Lint, SAST, Pytest, Trivy Scan, Deploy Gate)",
'''name: OmniPay Continuous Integration & Quality Delivery Pipeline
on:
  push:
    branches: [ main ]
    tags: [ 'v*.*.*' ]
  pull_request:
    branches: [ main ]

jobs:
  lint-and-sast:
    name: Code Quality & Static Security Analysis (Shift-Left)
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - name: Lint Code with Flake8
        run: flake8 . --count --max-line-length=127 --statistics
      - name: Security Scan with Bandit (SAST)
        run: bandit -r app/ -ll -ii

  test-and-coverage:
    name: Automated Unit & Integration Testing
    needs: lint-and-sast
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      - run: pip install -r requirements.txt
      - name: Run Pytest Test Suite with Coverage Gate
        run: pytest --cov=app --cov-fail-under=85 tests/

  container-build-and-scan:
    name: Container Packaging & Vulnerability Scan (Trivy)
    needs: test-and-coverage
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build Docker Image
        run: docker build -t omnipay-api:${{ github.sha }} .
      - name: Scan Docker Image with Trivy
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: 'omnipay-api:${{ github.sha }}'
          severity: 'CRITICAL,HIGH'

  deploy-blue-green:
    name: Blue/Green Staging & Production Deployment Gate
    needs: container-build-and-scan
    if: github.ref == 'refs/heads/main' || startsWith(github.ref, 'refs/tags/v')
    runs-on: ubuntu-latest
    steps:
      - run: echo "Deploying immutable image omnipay-api:${{ github.sha }} to Green Target Group..."''', bg_hex="F8FAFC", border_hex="F59E0B")

    # Appendix E
    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "Appendix E: Declarative Terraform Infrastructure-as-Code Modules", 12, 8, 4, COLOR_SECONDARY)
    
    add_callout(doc, "FILE: terraform/main.tf (VPC, Subnets, ALB, ECS Fargate & Blue/Green Target Groups)",
'''# Application Load Balancer
resource "aws_lb" "api_alb" {
  name               = "omnipay-${var.environment}-alb"
  internal           = false
  load_balancer_type = "application"
  subnets            = [aws_subnet.public_1.id, aws_subnet.public_2.id]
}

# Blue Target Group (Active)
resource "aws_lb_target_group" "blue" {
  name        = "omnipay-tg-blue"
  port        = 5000
  protocol    = "HTTP"
  vpc_id      = aws_vpc.main.id
  target_type = "ip"
  health_check {
    path = "/healthz"
    matcher = "200"
  }
}

# Green Target Group (Canary / Staging)
resource "aws_lb_target_group" "green" {
  name        = "omnipay-tg-green"
  port        = 5000
  protocol    = "HTTP"
  vpc_id      = aws_vpc.main.id
  target_type = "ip"
  health_check {
    path = "/healthz"
    matcher = "200"
  }
}

# ECS Cluster & Fargate Task Definition
resource "aws_ecs_cluster" "main" {
  name = "omnipay-${var.environment}-cluster"
}

resource "aws_ecs_task_definition" "api" {
  family                   = "omnipay-api-task"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = "512"
  memory                   = "1024"
  container_definitions = jsonencode([{
    name      = "omnipay-api"
    image     = var.container_image
    essential = true
    portMappings = [{ containerPort = 5000, hostPort = 5000 }]
  }])
}''', bg_hex="F8FAFC", border_hex="6366F1")

    # Appendix F
    p_h2 = doc.add_paragraph()
    format_heading(p_h2, "Appendix F: Git Branching History, PR Merges, and Release Tag v1.0.0", 12, 8, 4, COLOR_SECONDARY)
    
    add_callout(doc, "GIT LOG: git log --graph --oneline --all --decorate",
'''*   9035bdf (HEAD -> main, tag: v1.0.0) Merge pull request #4 from feature/cicd-and-terraform into main
|\\  
| * d12550d (feature/cicd-and-terraform) feat(devops): add github actions devsecops pipeline and terraform iac modules
|/  
*   c5c262d Merge pull request #3 from feature/docker-containerization into main
|\\  
| * 763e1dc (feature/docker-containerization) feat(docker): add multi-stage dockerfile with non-root security hardening
|/  
*   9e4a58b Merge pull request #2 from feature/automated-test-suite into main
|\\  
| * 95ddbde (feature/automated-test-suite) test(suite): add pytests for auth, payments, health and coverage gates
|/  
*   1372fa4 Merge pull request #1 from feature/core-api-auth into main
|\\  
| * d2fa2b2 (feature/core-api-auth) feat(auth): implement jwt authentication and payment routes
|/  
* 52cd787 chore(init): initial repository scaffolding and requirements''', bg_hex="F8FAFC", border_hex="059669")

    out_docx_path = r"C:\Users\Esha\Downloads\DevOps_Assignment_Submission\DevOps_Delivery_Strategy_Report.docx"
    doc.save(out_docx_path)
    print(f"Report saved to {out_docx_path}")
    
    out_docx_main = r"C:\Users\Esha\Downloads\DevOps_Assignment_Submission\DevOps_Delivery_Strategy_Report main .docx"
    doc.save(out_docx_main)
    print(f"Report saved to {out_docx_main}")

build_docx()

import win32com.client

def convert_to_pdf(docx_path, pdf_path):
    print(f"Converting {docx_path} -> {pdf_path}...")
    word = win32com.client.Dispatch('Word.Application')
    word.Visible = False
    try:
        d = word.Documents.Open(os.path.abspath(docx_path))
        d.SaveAs(os.path.abspath(pdf_path), FileFormat=17) # 17 = wdFormatPDF
        d.Close()
        print("PDF Conversion successful!")
    finally:
        word.Quit()

convert_to_pdf(r"C:\Users\Esha\Downloads\DevOps_Assignment_Submission\DevOps_Delivery_Strategy_Report.docx",
               r"C:\Users\Esha\Downloads\DevOps_Assignment_Submission\DevOps_Delivery_Strategy_Report.pdf")

convert_to_pdf(r"C:\Users\Esha\Downloads\DevOps_Assignment_Submission\DevOps_Delivery_Strategy_Report main .docx",
               r"C:\Users\Esha\Downloads\DevOps_Assignment_Submission\DevOps_Delivery_Strategy_Report main .pdf")

