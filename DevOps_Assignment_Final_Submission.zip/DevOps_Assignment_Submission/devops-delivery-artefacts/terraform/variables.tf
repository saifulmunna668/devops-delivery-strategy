variable "aws_region" {
  description = "AWS Primary Region"
  type        = string
  default     = "eu-west-1"
}

variable "environment" {
  description = "Deployment environment name"
  type        = string
  default     = "production"
}

variable "vpc_cidr" {
  description = "VPC CIDR Block"
  type        = string
  default     = "10.0.0.0/16"
}

variable "container_image" {
  description = "Immutable ECR Container Image URI"
  type        = string
  default     = "123456789012.dkr.ecr.eu-west-1.amazonaws.com/omnipay-api:v1.0.0"
}

variable "app_count" {
  description = "Number of ECS Fargate tasks to run"
  type        = number
  default     = 2
}
