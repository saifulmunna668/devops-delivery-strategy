output "alb_dns_name" {
  description = "DNS endpoint of the Application Load Balancer"
  value       = aws_lb.api_alb.dns_name
}

output "ecs_cluster_name" {
  description = "Name of the provisioned ECS cluster"
  value       = aws_ecs_cluster.main.name
}

output "blue_target_group_arn" {
  description = "ARN of the Active Blue Target Group"
  value       = aws_lb_target_group.blue.arn
}

output "green_target_group_arn" {
  description = "ARN of the Staging Green Target Group"
  value       = aws_lb_target_group.green.arn
}
