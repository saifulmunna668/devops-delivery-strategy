def test_liveness_probe(client):
    response = client.get('/healthz')
    assert response.status_code == 200
    assert response.get_json()['status'] == 'HEALTHY'

def test_readiness_probe(client):
    response = client.get('/readyz')
    assert response.status_code == 200
    assert response.get_json()['status'] == 'READY'

def test_prometheus_metrics_endpoint(client):
    response = client.get('/metrics')
    assert response.status_code == 200
    assert b'http_requests_total' in response.data or b'process_cpu_seconds_total' in response.data or b'# HELP' in response.data
