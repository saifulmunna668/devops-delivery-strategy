def test_create_payment_success(client, auth_headers):
    response = client.post('/api/v1/payments', headers=auth_headers, json={
        'recipient_email': 'merchant@store.com',
        'amount': 250.75,
        'currency': 'EUR'
    })
    assert response.status_code == 201
    data = response.get_json()
    assert data['message'] == 'Payment processed successfully'
    assert data['transaction']['amount'] == 250.75
    assert data['transaction']['currency'] == 'EUR'
    assert data['transaction']['status'] == 'COMPLETED'

def test_create_payment_invalid_amount(client, auth_headers):
    response = client.post('/api/v1/payments', headers=auth_headers, json={
        'recipient_email': 'merchant@store.com',
        'amount': -50.00,
        'currency': 'EUR'
    })
    assert response.status_code == 400
    assert 'greater than zero' in response.get_json()['error']

def test_unauthorized_payment_rejected(client):
    response = client.post('/api/v1/payments', json={
        'recipient_email': 'merchant@store.com',
        'amount': 100.00
    })
    assert response.status_code == 401
    assert 'missing' in response.get_json()['error']

def test_get_payment_history_and_stats(client, auth_headers):
    client.post('/api/v1/payments', headers=auth_headers, json={
        'recipient_email': 'vendor1@store.com',
        'amount': 100.00,
        'currency': 'EUR'
    })
    client.post('/api/v1/payments', headers=auth_headers, json={
        'recipient_email': 'vendor2@store.com',
        'amount': 200.00,
        'currency': 'EUR'
    })
    
    # Check history
    history_res = client.get('/api/v1/payments', headers=auth_headers)
    assert history_res.status_code == 200
    txs = history_res.get_json()['transactions']
    assert len(txs) == 2

    # Check stats
    stats_res = client.get('/api/v1/dashboard/stats', headers=auth_headers)
    assert stats_res.status_code == 200
    stats = stats_res.get_json()
    assert stats['total_transactions'] == 2
    assert stats['total_volume_eur'] == 300.00
