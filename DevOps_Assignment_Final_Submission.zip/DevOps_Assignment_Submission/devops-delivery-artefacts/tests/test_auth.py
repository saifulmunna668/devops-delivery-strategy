def test_user_registration_success(client):
    response = client.post('/api/v1/auth/register', json={
        'username': 'alice_fintech',
        'email': 'alice@omnipay.io',
        'password': 'Password99!'
    })
    assert response.status_code == 201
    assert response.get_json()['message'] == 'User registered successfully'

def test_duplicate_registration_fails(client):
    client.post('/api/v1/auth/register', json={
        'username': 'bob_fintech',
        'email': 'bob@omnipay.io',
        'password': 'Password99!'
    })
    response = client.post('/api/v1/auth/register', json={
        'username': 'bob_fintech',
        'email': 'bob_different@omnipay.io',
        'password': 'Password99!'
    })
    assert response.status_code == 409
    assert 'already exists' in response.get_json()['error']

def test_user_login_success(client):
    client.post('/api/v1/auth/register', json={
        'username': 'charlie',
        'email': 'charlie@omnipay.io',
        'password': 'StrongPassword123'
    })
    response = client.post('/api/v1/auth/login', json={
        'username': 'charlie',
        'password': 'StrongPassword123'
    })
    assert response.status_code == 200
    data = response.get_json()
    assert 'token' in data
    assert data['username'] == 'charlie'

def test_user_login_invalid_password(client):
    client.post('/api/v1/auth/register', json={
        'username': 'david',
        'email': 'david@omnipay.io',
        'password': 'CorrectPassword123'
    })
    response = client.post('/api/v1/auth/login', json={
        'username': 'david',
        'password': 'WrongPassword!'
    })
    assert response.status_code == 401
    assert response.get_json()['error'] == 'Invalid credentials'
