import os
import sys
import pytest

# Ensure app module is in python path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app, db
from app.models import User

@pytest.fixture
def app():
    app = create_app('testing')
    with app.app_context():
        db.create_all()
        yield app
        db.session.remove()
        db.drop_all()

@pytest.fixture
def client(app):
    return app.test_client()

@pytest.fixture
def auth_headers(client):
    # Register and login a default test user
    client.post('/api/v1/auth/register', json={
        'username': 'devops_tester',
        'email': 'tester@omnipay.io',
        'password': 'SecurePassword123!'
    })
    res = client.post('/api/v1/auth/login', json={
        'username': 'devops_tester',
        'password': 'SecurePassword123!'
    })
    token = res.get_json()['token']
    return {'Authorization': f'Bearer {token}'}
