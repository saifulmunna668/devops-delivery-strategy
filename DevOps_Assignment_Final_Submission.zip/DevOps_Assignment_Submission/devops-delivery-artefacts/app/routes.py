import uuid
from flask import Blueprint, request, jsonify
from app import db
from app.models import PaymentTransaction
from app.auth import token_required

api_bp = Blueprint('api', __name__, url_prefix='/api/v1')

@api_bp.route('/payments', methods=['POST'])
@token_required
def create_payment(current_user):
    data = request.get_json() or {}
    recipient_email = data.get('recipient_email')
    amount = data.get('amount')
    currency = data.get('currency', 'EUR')

    if not recipient_email or amount is None:
        return jsonify({'error': 'Recipient email and amount are required'}), 400

    try:
        amount_val = float(amount)
        if amount_val <= 0:
            return jsonify({'error': 'Payment amount must be greater than zero'}), 400
    except ValueError:
        return jsonify({'error': 'Invalid amount format'}), 400

    tx = PaymentTransaction(
        sender_id=current_user.id,
        recipient_email=recipient_email,
        amount=amount_val,
        currency=currency.upper(),
        status='COMPLETED',
        reference_id=str(uuid.uuid4())
    )
    db.session.add(tx)
    db.session.commit()

    return jsonify({'message': 'Payment processed successfully', 'transaction': tx.to_dict()}), 201

@api_bp.route('/payments', methods=['GET'])
@token_required
def get_payments(current_user):
    txs = PaymentTransaction.query.filter_by(sender_id=current_user.id).order_by(PaymentTransaction.created_at.desc()).all()
    return jsonify({'transactions': [t.to_dict() for t in txs]}), 200

@api_bp.route('/dashboard/stats', methods=['GET'])
@token_required
def get_stats(current_user):
    txs = PaymentTransaction.query.filter_by(sender_id=current_user.id).all()
    total_volume = sum(t.amount for t in txs)
    total_count = len(txs)
    return jsonify({
        'total_transactions': total_count,
        'total_volume_eur': total_volume,
        'active_currency': 'EUR'
    }), 200
