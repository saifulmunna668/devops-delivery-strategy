from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

db = SQLAlchemy()
bcrypt = Bcrypt()

def create_app(config_name='default'):
    app = Flask(__name__)
    if config_name == 'testing':
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['SECRET_KEY'] = 'test-secret-key-12345-long-secure-key-32bytes!'
    else:
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///omnipay.db'
        app.config['SECRET_KEY'] = 'prod-env-secret-key-omnipay-long-secure-key-32bytes!'
    
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    bcrypt.init_app(app)

    from app.routes import api_bp
    from app.auth import auth_bp
    from app.health import health_bp

    app.register_blueprint(api_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(health_bp)

    with app.app_context():
        db.create_all()

    return app
