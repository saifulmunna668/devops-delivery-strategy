from flask import Blueprint, jsonify, Response
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

health_bp = Blueprint('health', __name__)

REQUEST_COUNT = Counter('http_requests_total', 'Total HTTP Requests', ['method', 'endpoint', 'status'])
REQUEST_LATENCY = Histogram('http_request_duration_seconds', 'HTTP Request Duration')

@health_bp.route('/healthz', methods=['GET'])
def liveness():
    return jsonify({'status': 'HEALTHY', 'version': '1.0.0'}), 200

@health_bp.route('/readyz', methods=['GET'])
def readiness():
    # Verify database connectivity
    try:
        from app import db
        db.session.execute(db.text('SELECT 1'))
        return jsonify({'status': 'READY', 'database': 'CONNECTED'}), 200
    except Exception as e:
        return jsonify({'status': 'NOT_READY', 'error': str(e)}), 503

@health_bp.route('/metrics', methods=['GET'])
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)
