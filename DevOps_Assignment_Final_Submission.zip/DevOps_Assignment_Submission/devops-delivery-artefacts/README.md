# OmniPay Financial Technologies — DevOps Artefact Repository

This repository provides the supporting practical artefacts for the **MQF/EQF Level 5 Award in Introduction to DevOps: Principles and Practices** (10 ECTS) Individual Project Assessment.

## Repository Contents & Architecture
- `app/`: Production-ready Python/Flask REST API with JWT authentication, transaction endpoints, and Prometheus metrics.
- `tests/`: Multi-tiered automated test suite executed with Pytest (Unit tests, Integration tests, Health check probes).
- `.github/workflows/ci-cd.yml`: End-to-end GitHub Actions pipeline with Linting (Flake8), Static Security Analysis (Bandit), Automated Pytest execution, Container Vulnerability Scanning (Trivy), and Blue/Green canary deployment gate.
- `Dockerfile`: Multi-stage, non-root hardened container definition.
- `docker-compose.yml`: Multi-container local execution stack.
- `terraform/`: Declarative Infrastructure-as-Code modules for AWS VPC, ALB, ECS Fargate, and RDS.

## How to Run Tests Locally
```bash
python -m venv .venv
# On Windows:
.venv\Scripts\activate
# On Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
pytest -v --cov=app
```

## How to Run Container Locally
```bash
docker compose up --build
```
Access health endpoint: `http://localhost:5000/healthz`
Access Prometheus metrics: `http://localhost:5000/metrics`
