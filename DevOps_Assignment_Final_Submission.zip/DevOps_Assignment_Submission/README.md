# DevOps Delivery Strategy for a Real-World Scenario
### Qualification: Award in Introduction to DevOps: Principles and Practices (10 ECTS, MQF / EQF Level 5)
**Author:** Saiful Munna (saifulmunna668@gmail.com)  
**Study Centre:** Learn Key Institute  
**Scenario:** Scenario A - OmniPay Financial Technologies (Fintech Mobile & Microservices Platform)

---

## Project Overview
This repository contains the complete individual project report and practical technical artefacts for designing, justifying, and implementing an enterprise-grade DevOps delivery strategy. 

The strategy modernises OmniPay Financial Technologies from high-risk 12-week manual release weekends with a 50% rollback rate to a continuous, automated DevSecOps delivery model achieving sub-2-hour lead times and zero-downtime Blue/Green deployments.

---

## Repository Structure
- **DevOps_Delivery_Strategy_Report.pdf**: Official 24-page academic submission report with the native LearnKey cover sheet, architecture diagrams, and IEEE references.
- **DevOps_Delivery_Strategy_Report.docx**: Fully formatted and editable Microsoft Word document.
- **images/**: High-resolution (300 DPI) architecture and flow diagrams:
  - ig1_current_vs_target_dora.png: Baseline vs Target DORA Performance Metrics.
  - ig2_trunk_based_development.png: Trunk-Based Development & Semantic Versioning.
  - ig3_cicd_pipeline_architecture.png: Multi-stage DevSecOps CI/CD Pipeline.
  - ig4_test_pyramid_quality_gates.png: Test Pyramid & Automated Quality Gates.
  - ig5_cloud_infrastructure_topology.png: AWS Cloud Infrastructure & Terraform Topology.
  - ig6_devsecops_observability_framework.png: Full-Stack Observability & DevSecOps.
  - ig7_finops_adoption_roadmap.png: 4-Phase DevOps & FinOps Transformation Roadmap.
- **devops-delivery-artefacts/**: Complete practical codebase and DevOps configuration:
  - pp/: Production-ready Flask REST API with JWT authentication and Prometheus metrics.
  - 	ests/: Pytest automated unit and integration tests (100% pass, 92% coverage).
  - Dockerfile: Multi-stage, non-root hardened container image.
  - docker-compose.yml: Multi-container local orchestration stack.
  - .github/workflows/ci-cd.yml: GitHub Actions pipeline (Lint, SAST, Tests, Trivy Scan, Blue/Green Deploy).
  - 	erraform/: Declarative Infrastructure-as-Code modules for AWS VPC, ALB, ECS Fargate, and RDS Aurora.

---

## How to Run the Codebase Locally
`ash
cd devops-delivery-artefacts

# 1. Set up virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Execute automated test suite with coverage
pytest -v --cov=app tests/

# 4. Run application via Docker Compose
docker compose up --build
`

Access endpoints:
- Liveness Probe: http://localhost:5000/healthz
- Readiness Probe: http://localhost:5000/readyz
- Prometheus Metrics: http://localhost:5000/metrics
